package com.gyhqq.export.vo;

import javax.xml.bind.annotation.XmlRootElement;

import com.gyhqq.export.domain.Export;
@XmlRootElement(name="export")
public class ExportVo extends Export {

	
}
