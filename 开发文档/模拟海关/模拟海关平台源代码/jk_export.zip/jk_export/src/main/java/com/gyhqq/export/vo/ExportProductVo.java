package com.gyhqq.export.vo;

import javax.xml.bind.annotation.XmlRootElement;

import com.gyhqq.export.domain.ExportProduct;





/**
 * @Description:	ExportProductService接口
 * @CreateDate:		2016-7-7 0:05:42
 */
@XmlRootElement(name="exportProduct")
public class ExportProductVo extends ExportProduct {

	
}
